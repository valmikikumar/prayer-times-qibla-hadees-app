# Prayer Times, Qibla & Hadees App

A comprehensive Flutter Android app for Muslims featuring prayer times, Qibla direction, and Hadees collection.

## Features

### 🔹 Core Features

#### 1. Prayer Times
- Fetch prayer timings using AlAdhan API
- Automatically detect location using Geolocator
- Manual city selection option
- Show 5 daily prayers: Fajr, Dhuhr, Asr, Maghrib, Isha
- Next prayer countdown with real-time updates
- Adhan notification with customizable sounds

#### 2. Qibla Finder
- Qibla compass using device sensors
- GPS-based Qibla map mode
- Real-time direction indicator
- Accuracy feedback

#### 3. Daily Hadees
- Local SQLite database with authentic Hadees
- Daily random Hadees display
- Search functionality by keyword
- Filter by collection (Bukhari, Muslim, etc.)
- Arabic text with English translation

#### 4. Additional Features
- **Digital Tasbeeh Counter**: Multiple counters with save/load
- **Islamic Calendar**: Hijri dates alongside Gregorian
- **Duas Collection**: Daily duas with Arabic text and meanings
- **Settings**: Prayer calculation methods, notifications, themes

### 🔹 UI/UX
- Material 3 design with Islamic theme
- Green and white color scheme
- Arabic calligraphy fonts (Amiri)
- Dark/Light mode support
- Bottom navigation with 4 main tabs

### 🔹 Notifications
- Local notifications for prayer times
- Daily Hadees notifications
- Customizable Adhan sounds

### 🔹 Monetization
- AdMob integration with banner ads
- Interstitial ads between screens
- Premium version to remove ads

## Technical Stack

- **Framework**: Flutter (latest stable)
- **State Management**: Provider
- **Database**: SQLite (sqflite)
- **Backend**: Firebase (optional)
- **Location**: Geolocator
- **Sensors**: Flutter Compass
- **Notifications**: flutter_local_notifications
- **Ads**: google_mobile_ads
- **HTTP**: Dio
- **UI**: Material 3, Google Fonts

## Installation

1. **Prerequisites**
   - Flutter SDK (latest stable)
   - Android Studio
   - Android SDK

2. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd prayer-time
   ```

3. **Install dependencies**
   ```bash
   flutter pub get
   ```

4. **Run the app**
   ```bash
   flutter run
   ```

## Configuration

### AdMob Setup
1. Create an AdMob account
2. Create ad units for banner and interstitial ads
3. Replace test ad unit IDs in `lib/widgets/ad_banner.dart`

### API Keys
- AlAdhan API: No API key required (free)
- Location services: Configure in AndroidManifest.xml

## Project Structure

```
lib/
├── main.dart                 # App entry point
├── models/                   # Data models
│   ├── prayer_time.dart
│   └── hadees.dart
├── providers/                # State management
│   ├── app_provider.dart
│   ├── prayer_provider.dart
│   ├── hadees_provider.dart
│   └── settings_provider.dart
├── screens/                  # Main screens
│   ├── main_screen.dart
│   ├── home_screen.dart
│   ├── qibla_screen.dart
│   ├── hadees_screen.dart
│   └── more_screen.dart
├── widgets/                  # Reusable widgets
│   ├── prayer_times_card.dart
│   ├── next_prayer_card.dart
│   ├── qibla_compass.dart
│   ├── tasbeeh_widget.dart
│   └── ...
├── services/                 # Business logic
│   ├── prayer_service.dart
│   ├── database_service.dart
│   └── notification_service.dart
└── utils/                    # Utilities
    └── theme.dart
```

## Key Features Implementation

### Prayer Times
- Real-time API integration with AlAdhan
- Location-based calculations
- Multiple calculation methods (ISNA, MWL, etc.)
- Countdown timers with automatic updates

### Qibla Compass
- Device sensor integration
- Real-time direction calculation
- Visual compass with accuracy indicators
- Map view with GPS integration

### Hadees Database
- SQLite database with sample data
- Search and filter functionality
- Arabic text rendering with proper fonts
- Category and source filtering

### Notifications
- Local notification scheduling
- Prayer time reminders
- Daily Hadees notifications
- Customizable notification sounds

## Customization

### Themes
- Light and dark mode support
- Islamic color scheme
- Arabic font integration
- Material 3 design system

### Settings
- Prayer calculation methods
- Notification preferences
- Language selection
- Theme customization

## Building for Production

1. **Update app version**
   ```yaml
   version: 1.0.0+1
   ```

2. **Configure signing**
   - Create keystore for Android
   - Update `android/app/build.gradle`

3. **Build APK**
   ```bash
   flutter build apk --release
   ```

4. **Build App Bundle**
   ```bash
   flutter build appbundle --release
   ```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and feedback:
- Email: support@prayertimesapp.com
- Website: www.prayertimesapp.com

## Acknowledgments

- AlAdhan API for prayer times
- Islamic scholars for authentic Hadees
- Flutter community for excellent packages
- Material Design for UI guidelines

---

**May Allah bless this project and make it beneficial for the Muslim community. Ameen.**
