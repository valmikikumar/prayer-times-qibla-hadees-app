# 🕌 Prayer Times, Qibla & Hadees App

A comprehensive Flutter Android app for Muslims featuring prayer times, Qibla direction, and Hadees collection.

[![Build Status](https://github.com/username/prayer-times-qibla-hadees-app/workflows/Build%20APK/badge.svg)](https://github.com/username/prayer-times-qibla-hadees-app/actions)
[![Flutter Version](https://img.shields.io/badge/Flutter-3.16.0-blue.svg)](https://flutter.dev/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

## 📱 Features

### 🔹 Core Features
- **🕌 Prayer Times**: Real-time prayer times with countdown
- **🧭 Qibla Compass**: GPS-based Qibla direction finder
- **📖 Hadees Collection**: Authentic Hadees with search
- **🧮 Digital Tasbeeh**: Multiple counters for Dhikr
- **📅 Islamic Calendar**: Hijri dates with Gregorian
- **❤️ Duas Collection**: Daily duas with Arabic text

### 🔹 Technical Features
- **Material 3 Design** with Islamic theme
- **Dark/Light Mode** support
- **Local Notifications** for prayer times
- **SQLite Database** for offline Hadees
- **AdMob Integration** for monetization
- **Multiple Languages** (English, Urdu, Arabic)

## 🚀 Quick Start

### Download APK
1. **Go to [Actions](https://github.com/username/prayer-times-qibla-hadees-app/actions)**
2. **Download latest APK** from the latest build
3. **Install on Android device**

### Build from Source
```bash
# Clone repository
git clone https://github.com/username/prayer-times-qibla-hadees-app.git

# Navigate to project
cd prayer-times-qibla-hadees-app

# Install dependencies
flutter pub get

# Build APK
flutter build apk --release
```

## 📱 Screenshots

### Home Screen
- Prayer times with countdown
- Today's Hadees
- Quick actions

### Qibla Screen
- Compass view
- Map view
- Direction indicator

### Hadees Screen
- Search functionality
- Filter by collection
- Arabic text with translation

### More Features
- Tasbeeh counter
- Duas collection
- Islamic calendar
- Settings

## 🛠️ Technical Stack

- **Framework**: Flutter 3.16.0
- **State Management**: Provider
- **Database**: SQLite (sqflite)
- **Location**: Geolocator
- **Sensors**: Flutter Compass
- **Notifications**: flutter_local_notifications
- **Ads**: google_mobile_ads
- **HTTP**: Dio
- **UI**: Material 3, Google Fonts

## 📁 Project Structure

```
lib/
├── main.dart                 # App entry point
├── models/                   # Data models
├── providers/                # State management
├── screens/                  # Main screens
├── widgets/                  # Reusable widgets
├── services/                 # Business logic
└── utils/                    # Utilities
```

## 🔧 Configuration

### API Keys
- **AlAdhan API**: No API key required (free)
- **AdMob**: Replace test IDs with your own

### Permissions
- **Location**: For prayer times and Qibla
- **Notifications**: For prayer reminders
- **Storage**: For offline Hadees database

## 📦 Dependencies

```yaml
dependencies:
  flutter:
    sdk: flutter
  provider: ^6.1.1
  http: ^1.1.0
  geolocator: ^10.1.0
  sqflite: ^2.3.0
  flutter_local_notifications: ^16.3.0
  google_mobile_ads: ^3.0.0
  # ... and more
```

## 🚀 Deployment

### GitHub Actions
The repository includes GitHub Actions for automatic APK building:
- **Trigger**: Push to main branch
- **Output**: APK file in Actions artifacts
- **Download**: From Actions tab

### Manual Build
```bash
# Debug build
flutter build apk

# Release build
flutter build apk --release

# App bundle
flutter build appbundle --release
```

## 🤝 Contributing

1. **Fork the repository**
2. **Create feature branch**: `git checkout -b feature/amazing-feature`
3. **Commit changes**: `git commit -m 'Add amazing feature'`
4. **Push to branch**: `git push origin feature/amazing-feature`
5. **Open Pull Request**

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **AlAdhan API** for prayer times
- **Islamic scholars** for authentic Hadees
- **Flutter community** for excellent packages
- **Material Design** for UI guidelines

## 📞 Support

- **GitHub Issues**: [Report bugs](https://github.com/username/prayer-times-qibla-hadees-app/issues)
- **GitHub Discussions**: [Ask questions](https://github.com/username/prayer-times-qibla-hadees-app/discussions)
- **Email**: support@prayertimesapp.com

---

**May Allah bless this project and make it beneficial for the Muslim community. Ameen.**


