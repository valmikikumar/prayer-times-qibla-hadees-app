package com.example.prayer_times_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
